---
name: Precision IoT Control
colors:
  surface: '#f8f9ff'
  surface-dim: '#cbdbf5'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff4ff'
  surface-container: '#e5eeff'
  surface-container-high: '#dce9ff'
  surface-container-highest: '#d3e4fe'
  on-surface: '#0b1c30'
  on-surface-variant: '#434655'
  inverse-surface: '#213145'
  inverse-on-surface: '#eaf1ff'
  outline: '#737686'
  outline-variant: '#c3c6d7'
  surface-tint: '#0053db'
  primary: '#004ac6'
  on-primary: '#ffffff'
  primary-container: '#2563eb'
  on-primary-container: '#eeefff'
  inverse-primary: '#b4c5ff'
  secondary: '#565e74'
  on-secondary: '#ffffff'
  secondary-container: '#dae2fd'
  on-secondary-container: '#5c647a'
  tertiary: '#006242'
  on-tertiary: '#ffffff'
  tertiary-container: '#007d55'
  on-tertiary-container: '#bdffdb'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dbe1ff'
  primary-fixed-dim: '#b4c5ff'
  on-primary-fixed: '#00174b'
  on-primary-fixed-variant: '#003ea8'
  secondary-fixed: '#dae2fd'
  secondary-fixed-dim: '#bec6e0'
  on-secondary-fixed: '#131b2e'
  on-secondary-fixed-variant: '#3f465c'
  tertiary-fixed: '#6ffbbe'
  tertiary-fixed-dim: '#4edea3'
  on-tertiary-fixed: '#002113'
  on-tertiary-fixed-variant: '#005236'
  background: '#f8f9ff'
  on-background: '#0b1c30'
  surface-variant: '#d3e4fe'
typography:
  headline-lg:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: -0.005em
  body-md:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
  label-code-md:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: -0.02em
  label-code-sm:
    fontFamily: JetBrains Mono
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 14px
    letterSpacing: -0.01em
  label-ui:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.03em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  sidebar-w-collapsed: 64px
  sidebar-w-expanded: 240px
  table-row-h-dense: 36px
  table-row-h-standard: 44px
  gutter-canvas: 16px
  cell-px: 12px
  stack-gap-xs: 4px
  stack-gap-sm: 8px
  stack-gap-md: 12px
  panel-p: 12px
---

## Brand & Style

This design system is engineered for factory-floor hardware technicians, production test engineers, and fleet operations directors managing large-scale industrial IoT deployments. The environment demands immediate situational awareness, high-information throughput, and non-distracting visual hierarchy.

The aesthetic fuses **Utilitarian Minimalism** with **Industrial Precision**:
- **Data-First Utility:** Screen real estate prioritizes metrics, tabular hardware states, telemetry streaming, and diagnostics over decorative whitespace.
- **Factory-Grade Clarity:** Crisp boundary definitions, deterministic layouts, and instant status identification reduce operator error under pressure.
- **High-Density Legibility:** Compact typographic scales and tight vertical rhythms allow engineers to monitor dozens of concurrent node states, firmware provisioning queues, and bus traffic without excessive scrolling.
- **Dichromatic Structural Anchor:** An authoritative deep slate sidebar grounds persistent device topologies and navigation, transitioning to an ultra-clean, clinical neutral-gray workspace engineered for prolonged inspection under industrial lighting.

## Colors

The system uses a calibrated dual-surface structure: an anchor dark tier for navigation and a high-efficiency light slate workspace for operational data density.

### Core Architecture
- **Primary (`#2563EB` / `#1D4ED8` hover):** Focused interactive action color. Applied to critical action triggers, batch execution controls, selected table rows, active tabs, and primary key indicators.
- **Secondary / Shell Surface (`#0F172A` / `#1E293B`):** Deep carbon slate used exclusively for the fixed vertical navigation spine, collapsible diagnostic flyouts, and terminal output drawers. Provides visual separation between app scaffolding and real-time operational monitors.
- **Surface Canvas (`#F8FAFC`):** Background base layer engineered to eliminate glare while ensuring optimal contrast with dark slate text (`#0F172A`).
- **Surface Cards & Insets (`#FFFFFF` & `#F1F5F9`):** Pure white for elevated data tables, telemetry panels, and inspect sheets; slate-100 (`#F1F5F9`) for table headers, embedded filters, and disabled telemetry blocks.
- **Structural Dividers (`#E2E8F0`):** 1px borders providing structure without visual noise.

### Status Semantic System
Hardware telemetry relies on definitive, universally recognizable semantic tokens applied across pill tags, state dots, and telemetry indicators:
- **Online / Flashed / Nominal:** Emerald (`#10B981` text & border, `#ECFDF5` background).
- **Provisioning / Flashing / Warning:** Amber (`#F59E0B` text & border, `#FFFBEB` background).
- **Critical Failure / CRC Error / Offline Outage:** Rose (`#F43F5E` text & border, `#FFF1F2` background).
- **Decommissioned / Idle / Standby:** Slate (`#64748B` text & border, `#F1F5F9` background).

## Typography

The typographical hierarchy is calibrated for scan speed, structural alignment, and strict tabular precision.

### Typeface Roles
- **Primary Interface (Inter):** Applied across all structural UI labels, metrics cards, table headers, system alerts, and forms. Neutral geometry maximizes legibility at sub-14px sizes.
- **Technical & Telemetry Monospace (JetBrains Mono):** Mandatory for all machine-generated content: MAC addresses (e.g., `00:1A:2B:3C:4D:5E`), EUI-64 IDs, serial numbers, SHA-256 firmware checksums, JSON payloads, register hex addresses, and live factory-floor serial logs.

### Hierarchy & Usage Rules
- `headline-lg` (20px) is reserved for module and production-line view roots.
- Body levels sit tightly at `13px` and `12px` to accommodate dense multi-row parameter tables.
- Monospace tokens must strictly enforce `tabular-nums` alignment across all telemetry counters, millivolt metrics, and timestamp columns.
- Table headers use uppercase `label-ui` (11px / 600 weight) with positive letter-spacing (`0.03em`) and subdued slate color (`#64748B`) to establish clear data separation.

## Layout & Spacing

The layout model is anchored by a persistent dark administrative sidebar on the left and a continuous, responsive high-density operational canvas on the right.

### Master Frame
- **Left Navigation Frame:** Fixed-width 240px (collapsible to 64px icon-rail mode on secondary workstations) occupying `#0F172A`. Navigation groups divide by factory floor lines, provisioning batches, firmware catalogs, and diagnostic terminals.
- **Main Workspace Canvas:** Fluid canvas with an edge margin of `16px` (`gutter-canvas`). Content is contained in 12-column adaptive grids or full-bleed responsive tables designed to scale cleanly from 1280px rugged factory terminals up to ultra-wide 4K multi-line monitoring walls.

### Operational Spacing Grid
The horizontal and vertical rhythm follows a strict 4px base increment:
- **Tables:** Data density dictates strict vertical boundaries. Compact/factory mode runs at `table-row-h-dense` (36px per row) with `cell-px` (12px) horizontal padding. Standard review mode runs at `table-row-h-standard` (44px).
- **Control Headers:** Single-line persistent action bars (36px height) containing batch selections, search filters, branch switchers, and OTA dispatch triggers.
- **Card Panels:** Uniform `12px` interior padding (`panel-p`) prevents data bloat while allowing 4 to 6 metric panels to align above the primary data grid.

## Elevation & Depth

This design system avoids deep artistic drop shadows and heavy skeuomorphic effects. Depth is defined through crisp borders, flat color layering, and targeted low-radius surface separation.

### Surface Hierarchy
- **Level 0 (Canvas):** `#F8FAFC`. Base factory viewport background.
- **Level 1 (Panels, Cards, Grid Enclosures):** `#FFFFFF` framed by a 1px continuous `#E2E8F0` stroke. Zero drop shadow in default resting states.
- **Level 2 (Dropdown Menus, Popovers, Filter Trays):** `#FFFFFF` framed by a 1px `#CBD5E1` stroke with a micro-drop utility shadow: `0 4px 6px -1px rgba(15, 23, 42, 0.08), 0 2px 4px -2px rgba(15, 23, 42, 0.04)`.
- **Level 3 (Diagnostic Drawers, Modals, Serial Terminal Overlay):** Framed by `#CBD5E1` with a calibrated industrial shadow: `0 10px 15px -3px rgba(15, 23, 42, 0.12), 0 4px 6px -4px rgba(15, 23, 42, 0.08)`.

### Border Integrity
Every container boundary is explicit. In multi-pane terminal views, 1px lines (`#E2E8F0` on light surfaces, `#1E293B` on dark panels) govern column and row divisions to maintain scanning alignment.

## Shapes

The geometric architecture relies on **Soft (`roundedness: 1`)** micro-radii to maintain an engineered, hardware-adjacent feel. 

- **Containers & Data Cards:** Fixed at `6px` radius (`rounded-md`). 
- **Buttons, Text Inputs, and Filter Controls:** Fixed at `6px` radius (`rounded-md`).
- **Status Badges & Telemetry Pills:** Fully rounded `9999px` capsule radius for instantaneous visual differentiation from functional square inputs and cards.
- **Table Outlines:** Outer wrapper curved to `6px` radius with internal cells utilizing sharp right-angle dividers for optimal grid alignment.

## Components

### Buttons
- **Primary:** Height 32px (compact) or 36px (default). Background `#2563EB`, text `#FFFFFF`, radius 6px, weight 500 (`13px`). Hover: `#1D4ED8`. Active: `#1E40AF`.
- **Secondary / Outline:** Background `#FFFFFF`, border 1px solid `#E2E8F0`, text `#0F172A`. Hover: Background `#F1F5F9`, border `#CBD5E1`.
- **Destructive (Flash Abort / Decommission):** Background `#FFFFFF`, border 1px solid `#FECDD3`, text `#E11D48`. Hover: Background `#FFF1F2`, border `#FDA4AF`.
- **Icon Utility Actions:** 32x32px square buttons for copy-MAC, restart node, or ping diagnostics. Border 1px `#E2E8F0`, text `#64748B`, hover `#0F172A`.

### Status Badges & Pills
- **Geometry:** Height 20px, horizontal padding 8px, capsule-radius (9999px), font `JetBrains Mono` 11px weight 600.
- **Online / Active:** Green pill (`bg: #ECFDF5`, `text: #065F46`, `border: 1px solid #A7F3D0`), leading 6px pulsing dot `#10B981`.
- **Pending / Flashing:** Amber pill (`bg: #FFFBEB`, `text: #92400E`, `border: 1px solid #FDE68A`), leading 6px spinning indicator `#F59E0B`.
- **Error / Offline / Tamper:** Rose pill (`bg: #FFF1F2`, `text: #9F1239`, `border: 1px solid #FECDD3`), leading 6px static dot `#F43F5E`.
- **Standby:** Slate pill (`bg: #F1F5F9`, `text: #475569`, `border: 1px solid #E2E8F0`).

### Dense Data Tables
- **Header:** Height 32px, background `#F8FAFC`, bottom border 1px solid `#E2E8F0`. Text `label-ui` (11px, bold, uppercase, color `#64748B`).
- **Rows:** Alternating rows optional; standard uses continuous `#FFFFFF` separated by 1px bottom border `#F1F5F9`. Height 36px in dense technician mode, 44px in review mode. Hover state `#F8FAFC`.
- **Cells:** Fixed vertical centering. Monospace text for identifiers, hardware revs, RSSI signal values (`-68 dBm`), and IP allocations. Checkbox columns fixed at 36px width.

### Form Inputs & Search Filters
- **Text & Select Fields:** Height 32px. Background `#FFFFFF`, border 1px solid `#CBD5E1`, radius 6px, font size 13px Inter. Focus: Outline ring 2px `#2563EB` with 0px offset. Placeholder text: `#94A3B8`.
- **Global Serial/MAC Search:** Height 36px, leading search icon, internal shortcut chip (`⌘K` or `Ctrl+K`) positioned right in `JetBrains Mono`.

### Checkboxes & Selection
- **Square Checkbox:** 16x16px, 4px radius. Unchecked: border 1px solid `#CBD5E1`, background `#FFFFFF`. Checked: border `#2563EB`, background `#2563EB`, white checkmark SVG.

### Hardware Diagnostic Panel (Terminal Drawer)
- Fixed bottom or split-right flyout for engineers tracing JTAG, UART, or MQTT socket streams.
- Background `#0F172A`, text `#E2E8F0`, font `JetBrains Mono` 12px / line-height 18px.
- Timestamps highlighted in slate-500 (`#64748B`), warnings in amber-400 (`#FBBF24`), payload output in emerald-400 (`#34D399`). Includes continuous auto-scroll lock toggle and instant clipboard flush controls.